package pl.edu.agh.mwo.hellomaven;

import org.junit.Assert;
import org.junit.Test;

public class AppTest {

    /**
     * Sample test.
     */
    @Test
    public void sampleTest() {
        Assert.assertTrue(true);
    }
}
